function option(req, res){
    res.render('tasks/option');
}

function create(req, res){
    res.render('task/create');
}
function store(req, res){
    const data = req.body;
    req.getConnection((error, conexion)=>{
        conexion.query('INSERT INTO task SET ? ', [data], (error, renglones)=>{
            console.log(renglones);
            res.redirect('/task')
        });
    });
}
module.exports = {
    option: option,
    create: create,
    store: store
}