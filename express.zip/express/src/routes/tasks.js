const express = require('express');

const TaskController = require('../controllers/TaskController');

const route = express.Router();

route.get('/task', TaskController.option);
route.get('/create', TaskController.create);
route.get('/store', TaskController.store)

module.exports =  route